const config = require("./database/knex_config");
module.exports = config;
