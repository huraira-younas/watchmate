require("dotenv").config();
const runApp = require("./app");

runApp();
