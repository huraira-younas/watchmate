const expire = {
  report_values: 1440,
  sql_version: 1440,
  party_room: 1440,
  invite: 1440,
  user: 60,
  code: 30,
};
module.exports = expire;
