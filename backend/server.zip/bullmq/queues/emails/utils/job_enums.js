const jobs = {
  RESET_PASSWORD: "reset_password",
  SEND_CODE: "send_code",
};

module.exports = jobs;
